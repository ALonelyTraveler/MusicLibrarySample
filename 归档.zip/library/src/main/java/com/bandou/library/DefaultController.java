package com.bandou.library;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.util.Log;
import com.bandou.library.util.FileUtils;

import java.io.IOException;

/**
 * @ClassName: DefaultController
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:06
 */
public class DefaultController implements IMusicController {
    /**
     * 音乐播放实例
     */
    protected MediaPlayer mPlayer = null;

    private MusicPlayer mMusicPlayer = null;
    /**
     * ERROR:错误
     * IDLE:空闲
     * PREPARING:正在准备中
     * PLAYING:正在播放中
     * PAUSE:暂停中
     * COMPLETE:已经完成
     */
    public static final int ERROR = -1;
    public static final int IDLE = 0;
    public static final int PREPARING = 1;
    public static final int PLAYING = 2;
    public static final int PAUSE = 3;
    public static final int SINGLE_COMPLETE = 4;
    public static final int ALL_COMPLETE = 5;
    /**
     * {@link #play(String)}返回值的取值
     * NORMAL:未出现错误
     * ERROR_DATA:数据错误（路径不正确或AudioInfo对象为空)
     * ERROR_LOADING:加载时出现异常
     * ERROR_PLAYING:播放过程出现异常
     */
    public static final int NORMAL = 0;
    public static final int ERROR_DATA = 1;
    public static final int ERROR_LOADING = 2;
    public static final int ERROR_PLAYING = 3;

    /**
     * 当前状态
     */
    private int status = IDLE;

    @Override
    public int play(String path) {
        if (path == null || !FileUtils.isFileExist(path)) {
            if (mSender != null) {
                mSender.error(ERROR_DATA);
            }
            return ERROR_DATA;
        }
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
        }
        try {
            mPlayer.reset();
            status = PREPARING;
            mPlayer.setDataSource(path);
            mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mPlayer.setOnErrorListener(this);
            mPlayer.setOnBufferingUpdateListener(this);
            mPlayer.setOnCompletionListener(this);
            mPlayer.setOnPreparedListener(this);
            mPlayer.setOnSeekCompleteListener(this);
            mPlayer.prepareAsync();
        } catch (IOException e) {
            Log.i("MusicController", "Exception from initPlay");
            e.printStackTrace();
            if (mPlayer != null) {
                mPlayer.stop();
                mPlayer.release();
                mPlayer = null;
            }
            status = ERROR;
            if (mSender != null) {
                mSender.error(ERROR_LOADING);
            }
            stopProgressTimer();
            return ERROR_LOADING;
        }
        return NORMAL;
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void next() {

    }

    @Override
    public void previous() {

    }

    @Override
    public void stop() {

    }

    @Override
    public void seekTo(int progress) {

    }

    @Override
    public boolean isPlay() {
        return false;
    }

    @Override
    public boolean isWork() {
        return false;
    }

    @Override
    public int getProgress() {
        return 0;
    }

    private void sendMessage(int flag, Object... params) {

    }
}

package com.bandou.musiclibrary;

import com.bandou.musiclibrary.model.AudioInfo;
import com.bandou.musiclibrary.utils.AudiosSortUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: DefaultMusicPicker
 * @Description: 音乐列表控制
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午4:14
 */
public class DefaultMusicPicker extends AbstractMusicPicker {

    /**
     * 播放标记位
     * FLAG_INVALID:无效标记
     * FLAG_SORT:顺序播放
     * FLAG_LOOP:顺序循环播放
     * FLAG_RANDOM:随机播放
     */
    public final static int FLAG_INVALID = -1;
    public final static int FLAG_SORT = 0x00;
    public final static int FLAG_LOOP = 1<<1;
    public final static int FLAG_RANDOM = 1;

    /**
     * 当前播放模式
     */
    private int flag = FLAG_INVALID;
    @Override
    public AudioInfo next() {
        if (!isWork()) {
            return null;
        }
        if (playIndex >= mSourceAudios.size()-1) {
            playIndex = 0;
            if ((flag & FLAG_RANDOM) == FLAG_RANDOM) {
                shuffle(flag);
            }
        } else {
            playIndex++;
        }
        return mSourceAudios.get(playIndex);
    }
    @Override
    public boolean canNext() {
        if (isWork()) {
            return false;
        }
        if ((flag&FLAG_LOOP) == FLAG_LOOP&&playIndex<=mSourceAudios.size()-1) {
            return true;
        }
        return false;
    }

    @Override
    public boolean canPrevious() {
        if (isWork()) {
            return false;
        }
        return true;
    }

    @Override
    public void shuffle(int flag) {
        synchronized (DefaultMusicPicker.this) {
            if (!isWork()) {
                return;
            }
            this.flag = flag;
            boolean random = ((flag&FLAG_RANDOM)==FLAG_RANDOM);
            AudioInfo lastAudio = null;
            if (mSourceAudios != null && playIndex!=-1) {
                lastAudio = mSourceAudios.get(playIndex);
            }
            if (mSourceAudios.size() > 0) {
                if (random) {
                    AudiosSortUtils.sortByRandom(mSourceAudios);
                    if (lastAudio != null) {
                        if (mSourceAudios.remove(lastAudio)) {
                            mSourceAudios.add(0,lastAudio);
                        }
                    }
                    playIndex = 0;
                }
                else{
                    AudiosSortUtils.sortByOrder(mSourceAudios);
                    if (lastAudio != null) {
                        int index = mSourceAudios.indexOf(lastAudio);
                        if (index > 0) {
                            List<AudioInfo> subList = new ArrayList<AudioInfo>(mSourceAudios.subList(0, index));
                            if (mSourceAudios.removeAll(subList)) {
                                mSourceAudios.addAll(subList);
                            }
                        }
                    }
                    playIndex = 0;
                }
            }
        }
    }

}

package com.bandou.library;

/**
 * @ClassName: PlayerConfig
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:00
 */
public class PlayerConfig {

    private AbstractAudioManager mAudioManager;
    private IBroadcastSender mSender;
    private INotification mNotification;
    private IMusicController mController;

    public AbstractAudioManager getAudioManager() {
        return mAudioManager;
    }

    public PlayerConfig setAudioManager(AbstractAudioManager audioManager) {
        this.mAudioManager = audioManager;
        return this;
    }

    public IBroadcastSender getSender() {
        return mSender;
    }

    public PlayerConfig setSender(IBroadcastSender sender) {
        this.mSender = sender;
        return this;
    }

    public INotification getNotification() {
        return mNotification;
    }

    public PlayerConfig setNotification(INotification notification) {
        this.mNotification = notification;
        return this;
    }

    public IMusicController getController() {
        return mController;
    }

    public PlayerConfig setController(IMusicController controller) {
        this.mController = controller;
        return this;
    }

}

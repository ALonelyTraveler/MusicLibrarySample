package com.bandou.library;

/**
 * @ClassName: IBroadcastSender
 * @Description: 音乐状态广播发射器
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午10:59
 */
public interface IBroadcastSender {
    public void play(int progress);

    public void pause(int progress);

    public void error(int errorCode);

    public void singleComplete(int progress);

    public void allComplete(int progress);

    public void progress(int progress);
}

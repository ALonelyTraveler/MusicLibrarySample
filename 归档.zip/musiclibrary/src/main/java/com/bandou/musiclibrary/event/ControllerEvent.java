package com.bandou.musiclibrary.event;

/**
 * @ClassName: ControllerEvent
 * @Description: 控制器事件
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/8/1 上午11:35
 */
public class ControllerEvent {
}

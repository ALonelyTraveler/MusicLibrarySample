package com.bandou.library;

/**
 * @ClassName: MusicPlayer
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:07
 */
public class MusicPlayer {
    private static class MusicPlayerInstance {
        private static MusicPlayer sPlayer = new MusicPlayer();
    }

    public static MusicPlayer getInstance() {
        return MusicPlayerInstance.sPlayer;
    }

    private PlayerConfig mConfig;

    /**
     * Init in application.
     * 建议在应用的Application中初始化PlayerConfig,配置只能生成一次
     *
     * @param config the config
     */
    public void initInApplication(PlayerConfig config) {
        if (mConfig != null) {
            return;
        }
        if (config == null) {
            mConfig = new DefaultPlayerConfig();
        } else {
            mConfig = config;
        }
    }

    public PlayerConfig getConfig() {
        return mConfig;
    }

    public IMusicController getController() {
        return mConfig == null ? null : mConfig.getController();
    }

    public IBroadcastSender getSender() {
        return mConfig == null ? null : mConfig.getSender();
    }

    public INotification getNotification() {
        return mConfig == null ? null : mConfig.getNotification();
    }

    public AbstractAudioManager getAudioManager() {
        return mConfig == null ? null : mConfig.getAudioManager();
    }
}

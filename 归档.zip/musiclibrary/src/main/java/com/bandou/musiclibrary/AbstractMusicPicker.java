package com.bandou.musiclibrary;

import com.bandou.musiclibrary.model.AudioInfo;

import java.util.List;

/**
 * @ClassName: AbstractMusicPicker
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午4:12
 */
public abstract class AbstractMusicPicker {

    /**
     * 源列表数组
     */
    protected List<AudioInfo> mSourceAudios;

    /**
     * 当前播放的索引
     */
    protected int playIndex = -1;

    /**
     * 是否能运作
     *
     * @return
     */
    public boolean isWork() {
        return mSourceAudios != null && mSourceAudios.size() > 0 && playIndex >= 0 && playIndex < mSourceAudios.size();
    }

    public void setAudios(List<AudioInfo> audios) {
        synchronized (this) {
            this.mSourceAudios = audios;
        }
    }

    public void setPlayIndex(int playIndex) {
        synchronized (this) {
            this.playIndex = playIndex;
        }
    }

    public AudioInfo getCurrentAudio() {
        return mSourceAudios == null || playIndex < 0 || playIndex > mSourceAudios.size() - 1 ? null : mSourceAudios.get(playIndex);
    }

    public int getPlayIndex() {
        return this.playIndex;
    }

    public List<AudioInfo> getSourceAudios() {
        return mSourceAudios;
    }

    public AudioInfo next() {
        if (!isWork()) {
            return null;
        }
        if (playIndex >= mSourceAudios.size()-1) {
            playIndex = 0;
        } else {
            playIndex++;
        }
        return mSourceAudios.get(playIndex);
    }

    public AudioInfo previous() {
        if (!isWork()) {
            return null;
        }
        if (playIndex <= 0) {
            playIndex = mSourceAudios.size() - 1;
        } else {
            playIndex--;
        }
        return mSourceAudios.get(playIndex);
    }

    public abstract boolean canNext();

    public abstract boolean canPrevious();

    /**
     * 根据flag重新调整当前播放列表
     *
     * @param flag
     */
    public abstract void shuffle(int flag);

}

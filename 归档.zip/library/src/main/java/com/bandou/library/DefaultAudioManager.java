package com.bandou.library;

/**
 * @ClassName: DefaultAudioManager
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:05
 */
public class DefaultAudioManager extends AbstractAudioManager {
}

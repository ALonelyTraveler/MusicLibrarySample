package com.bandou.library;

/**
 * @ClassName: DefaultPlayerConfig
 * @Description: 默认播放配置,仅配置一个控制器
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:04
 */
public class DefaultPlayerConfig extends PlayerConfig {

    public DefaultPlayerConfig()
    {
        setController(new DefaultController());
        setAudioManager(null);
        setSender(null);
        setNotification(null);
    }
}

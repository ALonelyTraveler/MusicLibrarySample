package com.bandou.library;

/**
 * @ClassName: AbstractAudioManager
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午10:59
 */
public abstract class AbstractAudioManager {
}

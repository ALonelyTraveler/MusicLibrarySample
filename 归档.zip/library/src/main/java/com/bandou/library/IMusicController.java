package com.bandou.library;

/**
 * @ClassName: IMusicController
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:00
 */
public interface IMusicController {
    /**
     * Play. 播放指定音乐
     *
     * @param path the path 本地音乐路径
     * @return the boolean 是否初始化成功
     */
    public int play(String path);

    /**
     * Pause.
     * 暂停音乐
     */
    public void pause();

    /**
     * Resume.
     * 恢复播放
     */
    public void resume();

    /**
     * Next.
     * 播放下一首
     */
    public void next();

    /**
     * previous.
     * 播放上一首
     */
    public void previous();

    /**
     * Stop.
     * 停止音乐
     */
    public void stop();

    /**
     * Seek to.
     * 追加进度
     *
     * @param progress the progress
     */
    public void seekTo(int progress);

    /**
     * Is play boolean.
     * 音乐播放器是否处于播放状态
     *
     * @return the boolean
     */
    public boolean isPlay();

    /**
     * Is work boolean.
     * 音乐播放器是否处于工作状态
     *
     * @return the boolean
     */
    public boolean isWork();

    /**
     * Gets progress.
     * 获取当前播放进度
     * @return the progress
     */
    public int getProgress();
}

package com.bandou.musiclibrary;

/**
 * @ClassName: MusicManager
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午3:50
 */
public class MusicManager {

    private static class MusicControllerInstance {
        public static MusicController mController = new MusicController();
    }

    public static MusicController getController() {
        return MusicControllerInstance.mController;
    }

}

package com.bandou.musiclibrary;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.util.Log;
import com.bandou.library.util.FileUtils;
import com.bandou.musiclibrary.model.AudioInfo;

import java.io.IOException;

/**
 * @ClassName: MusicController
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午3:47
 */
public class MusicController extends AbstractMusicController {

    /**
     * ERROR:错误
     * IDLE:空闲
     * PREPARING:正在准备中
     * PLAYING:正在播放中
     * PAUSE:暂停中
     * COMPLETE:已经完成
     */
    public static final int ERROR = -1;
    public static final int IDLE = 0;
    public static final int PREPARING = 1;
    public static final int PLAYING = 2;
    public static final int PAUSE = 3;
    public static final int SINGLE_COMPLETE = 4;
    public static final int ALL_COMPLETE = 5;


    /**
     * {@link #play(String)}返回值的取值
     * NORMAL:未出现错误
     * ERROR_DATA:数据错误（路径不正确或AudioInfo对象为空)
     * ERROR_LOADING:加载时出现异常
     * ERROR_PLAYING:播放过程出现异常
     */
    public static final int NORMAL = 0;
    public static final int ERROR_DATA = 1;
    public static final int ERROR_LOADING = 2;
    public static final int ERROR_PLAYING = 3;

    /**
     * 当前状态
     */
    private int status = IDLE;

    private MusicTimer mTimer;

    public MusicController() {
    }

    @Override
    public int play(String path) {
        if (path == null || !FileUtils.isFileExist(path)) {
            if (mSender != null) {
                mSender.error(ERROR_DATA);
            }
            return ERROR_DATA;
        }
        if (mPlayer == null) {
            mPlayer = new MediaPlayer();
        }
        try {
            mPlayer.reset();
            status = PREPARING;
            mPlayer.setDataSource(path);
            mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mPlayer.setOnErrorListener(this);
            mPlayer.setOnBufferingUpdateListener(this);
            mPlayer.setOnCompletionListener(this);
            mPlayer.setOnPreparedListener(this);
            mPlayer.setOnSeekCompleteListener(this);
            mPlayer.prepareAsync();
        } catch (IOException e) {
            Log.i("MusicController", "Exception from initPlay");
            e.printStackTrace();
            if (mPlayer != null) {
                mPlayer.stop();
                mPlayer.release();
                mPlayer = null;
            }
            status = ERROR;
            if (mSender != null) {
                mSender.error(ERROR_LOADING);
            }
            stopProgressTimer();
            return ERROR_LOADING;
        }
        return NORMAL;
    }

    private void stopProgressTimer() {
        if (mTimer!=null&&mTimer.isLoading()) {
            mTimer.stopTimer();
        }
    }

    @Override
    public void pause() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
            status = PAUSE;
            if (mSender != null) {
                mSender.pause(getProgress());
            }
        }
    }

    @Override
    public void resume() {
        if (mPlayer != null && isWork()) {
            mPlayer.start();
            status = PLAYING;
            if (mSender != null) {
                mSender.play(mPlayer.getCurrentPosition());
            }
            startProgressTimer();
        }
    }

    private void startProgressTimer() {
        if (mTimer == null) {
            mTimer = new MusicTimer(this);
        }
        if (!mTimer.isLoading()) {
            mTimer.startTimer();
        }
    }

    @Override
    public void next(boolean auto) {
        if (mMusicBox != null && isWork()) {
            AudioInfo info = mMusicBox.next();
            if (info!=null&&info.getFileUri() != null) {
                play(info.getFileUri().getPath());
            }
        }
    }

    @Override
    public void previous() {
        if (mMusicBox != null && isWork()) {
            AudioInfo info = mMusicBox.previous();
            if (info!=null&&info.getFileUri() != null) {
                play(info.getFileUri().getPath());
            }
        }
    }

    @Override
    public void stop() {
        if (mPlayer != null) {
            stopProgressTimer();
            mPlayer.stop();
            mPlayer.release();
            mPlayer = null;
            status = IDLE;
        }
    }

    @Override
    public void seekTo(int progress) {
        if (mPlayer != null && isWork()) {
            mPlayer.seekTo(progress);
        }
    }

    @Override
    public boolean isPlay() {
        return status == PLAYING;
    }

    @Override
    public boolean isWork() {
        return mPlayer!=null&&status > PREPARING;
    }

    @Override
    public int getProgress() {
        return mPlayer != null && status > PREPARING ? mPlayer.getCurrentPosition() : 0;
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {

    }

    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        if (mMusicBox != null && mMusicBox.canNext()) {
            status = SINGLE_COMPLETE;
            if (mSender != null) {
                mSender.singleComplete(getProgress());
            }
            next(true);
        } else {
            status = ALL_COMPLETE;
            if (mSender != null) {
                mSender.allComplete(getProgress());
            }
        }
    }

    @Override
    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        stopProgressTimer();
        if (mPlayer != null) {
            mPlayer.stop();
            mPlayer.release();
            mPlayer = null;
        }
        status = ERROR;
        if (mSender != null) {
            mSender.error(ERROR_PLAYING);
        }
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {
        mediaPlayer.start();
        status = PLAYING;
        if (mSender != null) {
            mSender.play(0);
        }
        startProgressTimer();
    }

    @Override
    public void onSeekComplete(MediaPlayer mediaPlayer) {

    }
}

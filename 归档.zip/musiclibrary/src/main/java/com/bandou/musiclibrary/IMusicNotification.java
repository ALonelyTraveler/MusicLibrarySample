package com.bandou.musiclibrary;

import android.app.PendingIntent;
import com.bandou.musiclibrary.model.AudioInfo;

/**
 * @ClassName: IMusicNotification
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 上午11:57
 */
public interface IMusicNotification {
    /**
     * 在通知栏中显示
     * @param info  当前播放的音乐信息
     */
    public void showNotification(AudioInfo info);

    /**
     * 隐藏通知栏
     */
    public void hideNotification();

    /**
     * 更新音乐进度
     * @param progress
     */
    public void progressNotification(int progress);

    /**
     * 获取点击后的PendingIntent
     * @return
     */
    public PendingIntent getPendingIntent();
}

package com.bandou.musiclibrary;

import android.content.Context;
import android.media.AudioManager;
import com.bandou.library.util.SingletonUtils;

/**
 * The type Volume manager.
 *
 * @ClassName: VolumeManager
 * @Description: 音量管理
 * @author: chenwei
 * @version: V1.0
 * @Date: 16 /7/27 下午3:23
 */
public class VolumeManager extends SingletonUtils<VolumeManager>{

    @Override
    protected VolumeManager newInstance() {
        return new VolumeManager();
    }

    /**
     * Gets max volume.
     * 获取最大音量
     *
     * @param context the context
     * @return the max volume
     */
    public int getMaxVolume(Context context) {
        AudioManager mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        return mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
    }

    /**
     * Gets current volume.
     * 获取当前音量值
     *
     * @param context the context
     * @return the current volume
     */
    public int getCurrentVolume(Context context) {
        AudioManager mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        return mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
    }

    /**
     * Sets volume.
     * 设置音量
     *
     * @param context the context
     * @param volume  the volume
     */
    public void setVolume(Context context,int volume) {
        AudioManager mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        int max = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if (volume > max) {
            volume = max;
        }
        if (volume < 0) {
            volume = 0;
        }
        mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
    }

    /**
     * Decrease.
     * 减小音量，调出系统音量控制
     *
     * @param context the context
     */
    public void decrease(Context context) {
        AudioManager mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,
                AudioManager.FX_FOCUS_NAVIGATION_UP);
    }

    /**
     * Increase.
     * 增加音量，调出系统音量控制
     *
     * @param context the context
     */
    public void increase(Context context) {
        AudioManager mAudioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        mAudioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,
                AudioManager.FX_FOCUS_NAVIGATION_UP);
    }
}

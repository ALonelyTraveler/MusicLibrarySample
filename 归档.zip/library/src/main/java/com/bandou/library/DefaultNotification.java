package com.bandou.library;

/**
 * @ClassName: DefaultNotification
 * @Description: say something
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:07
 */
public class DefaultNotification implements INotification {
}

package com.bandou.musiclibrary;

import android.media.MediaPlayer;

/**
 * The type Abstract music controller.
 *
 * @ClassName: AbstractMusicController
 * @Description: 抽象音乐控制器
 * @author: chenwei
 * @version: V1.0
 * @Date: 16 /7/27 上午11:56
 */
public abstract class AbstractMusicController implements MediaPlayer.OnCompletionListener, MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnErrorListener{

    /**
     * 音乐播放实例
     */
    protected MediaPlayer mPlayer = null;
    /**
     * 播放音乐时的通知栏操作
     */
    protected IMusicNotification mNotification;

    /**
     * 音乐盒子
     */
    protected AbstractMusicPicker mMusicBox;

    /**
     * 状态发送者
     */
    protected IBroadcastSender mSender;

    /**
     * Sets notification.
     * 设置通知栏
     *
     * @param notification the notification
     */
    public void setNotification(IMusicNotification notification) {
        this.mNotification = notification;
    }

    /**
     * Gets notification.
     *
     * @return the notification
     */
    public IMusicNotification getNotification() {
        return mNotification;
    }

    /**
     * Sets music box.
     *
     * @param musicBox the music box
     */
    public void setMusicBox(AbstractMusicPicker musicBox) {
        this.mMusicBox = musicBox;
    }

    /**
     * Gets music box.
     *
     * @return the music box
     */
    public AbstractMusicPicker getMusicBox() {
        return mMusicBox;
    }

    /**
     * Sets sender.
     *
     * @param sender the sender
     */
    public void setSender(IBroadcastSender sender) {
        this.mSender = sender;
    }

    /**
     * Gets sender.
     *
     * @return the sender
     */
    public IBroadcastSender getSender() {
        return mSender;
    }

    /**
     * Play. 播放指定音乐
     *
     * @param path the path 本地音乐路径
     * @return the boolean 是否初始化成功
     */
    public abstract int play(String path);

    /**
     * Pause.
     * 暂停音乐
     */
    public abstract void pause();

    /**
     * Resume.
     * 恢复播放
     */
    public abstract void resume();

    /**
     * Next.
     * 播放下一首
     *
     * @param auto the auto  是否是自动播放下一首
     */
    public abstract void next(boolean auto);

    /**
     * previous.
     * 播放上一首
     */
    public abstract void previous();

    /**
     * Stop.
     * 停止音乐
     */
    public abstract void stop();

    /**
     * Seek to.
     * 追加进度
     *
     * @param progress the progress
     */
    public abstract void seekTo(int progress);

    /**
     * Is play boolean.
     * 音乐播放器是否处于播放状态
     *
     * @return the boolean
     */
    public abstract boolean isPlay();

    /**
     * Is work boolean.
     * 音乐播放器是否处于工作状态
     *
     * @return the boolean
     */
    public abstract boolean isWork();

    /**
     * Gets progress.
     * 获取当前播放进度
     * @return the progress
     */
    public abstract int getProgress();

}

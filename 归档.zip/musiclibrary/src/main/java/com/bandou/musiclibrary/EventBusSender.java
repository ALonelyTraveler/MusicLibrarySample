package com.bandou.musiclibrary;

import com.bandou.musiclibrary.event.MediaEvent;
import org.greenrobot.eventbus.EventBus;

/**
 * @ClassName: EventBusSender
 * @Description: 使用EventBus发送
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午4:54
 */
public class EventBusSender implements IBroadcastSender {
    @Override
    public void play(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PLAY, progress));
    }

    @Override
    public void pause(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PAUSE, progress));
    }

    @Override
    public void error(int errorCode) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_ERROR, MediaEvent.NO_SUPPORT_PROGRESS));
    }

    @Override
    public void singleComplete(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_SINGLE_COMPLETE, progress));
    }

    @Override
    public void allComplete(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_ALL_COMPLETE, progress));
    }

    @Override
    public void progress(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PROGRESS, progress));
    }
}

package com.bandou.musiclibrary;

/**
 * @ClassName: IBroadcastSender
 * @Description: 音乐播放广播发送器
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/27 下午4:48
 */
public interface IBroadcastSender {

    public void play(int progress);

    public void pause(int progress);

    public void error(int errorCode);

    public void singleComplete(int progress);

    public void allComplete(int progress);

    public void progress(int progress);
}

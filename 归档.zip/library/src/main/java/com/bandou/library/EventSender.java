package com.bandou.library;

import com.bandou.library.event.MediaEvent;
import org.greenrobot.eventbus.EventBus;

/**
 * @ClassName: EventSender
 * @Description: 使用EventBus广播消息
 * @author: chenwei
 * @version: V1.0
 * @Date: 16/7/29 上午11:06
 */
public class EventSender implements IBroadcastSender {
    @Override
    public void play(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PLAY, progress));
    }

    @Override
    public void pause(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PAUSE, progress));
    }

    @Override
    public void error(int errorCode) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_ERROR, MediaEvent.NO_SUPPORT_PROGRESS));
    }

    @Override
    public void singleComplete(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_SINGLE_COMPLETE, progress));
    }

    @Override
    public void allComplete(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_ALL_COMPLETE, progress));
    }

    @Override
    public void progress(int progress) {
        EventBus.getDefault().post(new MediaEvent(MediaEvent.ACTION_PROGRESS, progress));
    }
}

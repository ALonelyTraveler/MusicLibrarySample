package com.bandou.musiclibrary;

import java.util.Timer;
import java.util.TimerTask;

/**
 * The type Music timer.
 * 只有音乐处于播放状态时才开启监听并发送广播
 *
 * @ClassName: MusicTimer
 * @Description: 音乐进度timer
 * @author: chenwei
 * @version: V1.0
 * @Date: 16 /7/27 下午5:06
 */
public class MusicTimer {

    /**
     * 监听音乐播放位置的task
     */
    class MusicTimeTask extends TimerTask {
        @Override
        public void run() {
            if (mController.isPlay()) {
                if (mController.getSender() != null) {
                    mController.getSender().progress(mController.getProgress());
                }
            }
        }
    }

    private MusicTimeTask mTask = null;

    private Timer mTimer = null;

    private MusicController mController;

    /**
     * Instantiates a new Music timer.
     *
     * @param controller the controller
     */
    public MusicTimer(MusicController controller) {
        this.mController = controller;
    }

    /**
     * Start timer.
     * 开始实时获取当前进度
     */
    public void startTimer() {
        if (mTask == null) {
            mTask = new MusicTimeTask();
            mTimer = new Timer();
            mTimer.schedule(mTask, 0, 1000);
        }
    }

    /**
     * Stop timer.
     * 关闭进度获取
     */
    public void stopTimer() {
        if (mTask != null) {
            mTask.cancel();
            mTask = null;
        }
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
    }

    /**
     * Is loading boolean.
     *
     * @return the boolean
     */
    public boolean isLoading() {
        return mTask!=null;
    }
}
